#pragma once
#include <cmath>
#include <ctime>
#include <cstdlib>
#include <windows.h>

namespace Project5 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::PictureBox^  pbMain;
	protected:
	private: System::Windows::Forms::Button^  Task1;
	private: System::Windows::Forms::Button^  Task2;
	private: System::Windows::Forms::Button^  Task3;
	private: System::Windows::Forms::Button^  Task4;
	private: System::Windows::Forms::Button^  Clear;

	private: System::ComponentModel::IContainer^  components;

	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->pbMain = (gcnew System::Windows::Forms::PictureBox());
			this->Task1 = (gcnew System::Windows::Forms::Button());
			this->Task2 = (gcnew System::Windows::Forms::Button());
			this->Task3 = (gcnew System::Windows::Forms::Button());
			this->Task4 = (gcnew System::Windows::Forms::Button());
			this->Clear = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pbMain))->BeginInit();
			this->SuspendLayout();
			// 
			// pbMain
			// 
			this->pbMain->Location = System::Drawing::Point(12, 5);
			this->pbMain->Name = L"pbMain";
			this->pbMain->Size = System::Drawing::Size(470, 267);
			this->pbMain->TabIndex = 0;
			this->pbMain->TabStop = false;
			// 
			// Task1
			// 
			this->Task1->Location = System::Drawing::Point(546, 52);
			this->Task1->Name = L"Task1";
			this->Task1->Size = System::Drawing::Size(75, 23);
			this->Task1->TabIndex = 1;
			this->Task1->Text = L"Task 1";
			this->Task1->UseVisualStyleBackColor = true;
			this->Task1->Click += gcnew System::EventHandler(this, &MyForm::Task1_Click);
			// 
			// Task2
			// 
			this->Task2->Location = System::Drawing::Point(546, 91);
			this->Task2->Name = L"Task2";
			this->Task2->Size = System::Drawing::Size(75, 23);
			this->Task2->TabIndex = 2;
			this->Task2->Text = L"Task 2";
			this->Task2->UseVisualStyleBackColor = true;
			this->Task2->Click += gcnew System::EventHandler(this, &MyForm::Task2_Click);
			// 
			// Task3
			// 
			this->Task3->Location = System::Drawing::Point(546, 135);
			this->Task3->Name = L"Task3";
			this->Task3->Size = System::Drawing::Size(75, 23);
			this->Task3->TabIndex = 3;
			this->Task3->Text = L"Task 3";
			this->Task3->UseVisualStyleBackColor = true;
			this->Task3->Click += gcnew System::EventHandler(this, &MyForm::Task3_Click);
			// 
			// Task4
			// 
			this->Task4->Location = System::Drawing::Point(546, 175);
			this->Task4->Name = L"Task4";
			this->Task4->Size = System::Drawing::Size(75, 23);
			this->Task4->TabIndex = 4;
			this->Task4->Text = L"Task 4";
			this->Task4->UseVisualStyleBackColor = true;
			this->Task4->Click += gcnew System::EventHandler(this, &MyForm::Task4_Click);
			// 
			// Clear
			// 
			this->Clear->Location = System::Drawing::Point(524, 276);
			this->Clear->Name = L"Clear";
			this->Clear->Size = System::Drawing::Size(75, 23);
			this->Clear->TabIndex = 5;
			this->Clear->Text = L"Clear";
			this->Clear->UseVisualStyleBackColor = true;
			this->Clear->Click += gcnew System::EventHandler(this, &MyForm::Clear_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(695, 378);
			this->Controls->Add(this->Clear);
			this->Controls->Add(this->Task4);
			this->Controls->Add(this->Task3);
			this->Controls->Add(this->Task2);
			this->Controls->Add(this->Task1);
			this->Controls->Add(this->pbMain);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pbMain))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void Clear_Click(System::Object^  sender, System::EventArgs^  e) 
	{
		Graphics^ g = pbMain->CreateGraphics();
		g->Clear(SystemColors::Control);
	}
	 //�) ���������� � ����� ����� ������ ���������� ������������
	 //�����������, ����, ���� � ������������ ���������.
	//470x267
private: System::Void Task1_Click(System::Object^  sender, System::EventArgs^  e) 
{
	Graphics^ g = pbMain->CreateGraphics();
	g->Clear(SystemColors::Control);
	Pen^ pen = gcnew Pen(Color::LightGreen, 3);
	Brush^ brush = gcnew SolidBrush(Color::Red);
	double h = sqrt(50 * 50 - 25 * 25);
	Point point1 = Point(100, 100), point2 = Point(150, 100), point3 = Point(175, 100 + (int)h), point4 = Point(150, 100 + 2 * h), point5 = Point(100, 100 + 2 * h), point6 = Point(75, 100 + h);
	array <Point>^ Hexagon = { point1, point2, point3, point4, point5, point6 };
	g->FillPolygon(brush, Hexagon);

	g->DrawEllipse(pen, 20, 20, 100, 50);

	g->DrawEllipse(pen, 150, 20, 40, 40);

	Point TrianglePoint1 = Point(10, 210), TrianglePoint2 = Point(20, 260), TrianglePoint3 = Point(70, 230);
	array<Point>^ Triangle = { TrianglePoint1, TrianglePoint2, TrianglePoint3 };
	g->FillPolygon(brush, Triangle);
}

private: System::Void Task2_Click(System::Object^  sender, System::EventArgs^  e) 
{
	Graphics^ g = pbMain->CreateGraphics();
	g->Clear(SystemColors::Control);
	Pen^ pen = gcnew Pen(Color::Black, 3);
	Brush^ brush = gcnew SolidBrush(Color::ForestGreen);

	Point point1 = Point(138, 27), point2 = Point(192, 25), point3 = Point(206, 63), point4 = Point(117, 65);
	array<Point>^ Part1 = { point1, point2, point3, point4 };
	g->FillPolygon(brush, Part1);
	g->DrawPolygon(pen, Part1);
	g->FillPie(brush, 109, 32, 33, 31, 120, 180);
	g->DrawPie(pen, 109, 32, 33, 31, 120, 180);

	Point point5 = Point(95, 33), point6 = Point(114, 36), point7 = Point(109, 43), point8 = Point(91, 40);
	array <Point>^ Part2 = { point5, point6, point7, point8 };
	g->FillPolygon(brush, Part2);
	g->DrawPolygon(pen, Part2);

	Point point9 = Point(5, 22), point10 = Point(3, 29);
	array<Point>^ Part3 = { point9, point5, point8, point10 };
	g->FillPolygon(brush, Part3);
	g->DrawPolygon(pen, Part3);

	Point point11 = Point(90, 39), point12 = Point(109, 50), point13 = Point(89, 49);
	array <Point>^ Part4 = { point11, point7, point12, point13 };
	g->FillPolygon(brush, Part4);
	g->DrawPolygon(pen, Part4);

	Point point14 = Point(134, 65), point15 = Point(197, 64), point16 = Point(197, 71), point17 = Point(133, 72);
	array <Point>^ Part5 = { point14, point15, point16, point17 };
	g->FillPolygon(brush, Part5);
	g->DrawPolygon(pen, Part5);

	g->FillPie(brush, 88, 80, 16, 13, 130, 180);
	g->DrawPie(pen, 88, 80, 16, 13, 130, 180);

	Point point18 = Point(68, 105), point19 = Point(113, 72), point20 = Point(291, 70), point21 = Point(333, 108);
	array <Point>^ Part6 = { point18, point19, point20, point21 };
	g->FillPolygon(brush, Part6);
	g->DrawPolygon(pen, Part6);

	Pen^ pen2 = gcnew Pen(Color::Black, 6);
	Point point22 = Point(28, 112), point23 = Point(36, 109), point24 = Point(53, 107), point25 = Point(272, 108), point26 = Point(323, 109), point27 = Point(339, 112), point28 = Point(346, 117), point29 = Point(349, 124), point30 = Point(347, 131), point31 = Point(312, 149), point32 = Point(306, 152), point33 = Point(295, 154), point34 = Point(284, 155), point35 = Point(80, 155), point36 = Point(71, 153), point37 = Point(62, 149), point38 = Point(32, 130), point39 = Point(26, 124), point40 = Point(25, 119), point41 = Point(27, 112);
	array <Point>^ Part7 = { point22, point23, point24, point25, point26, point27, point29, point30, point31, point32, point33, point34, point35, point36, point37, point38, point39, point40, point41 };
	g->FillPolygon(brush, Part7);
	g->DrawPolygon(pen2, Part7);

	g->DrawEllipse(pen2, 59, 106, 45, 47);
	g->DrawEllipse(pen2, 113, 107, 46, 48);
	g->DrawEllipse(pen2, 167, 107, 46, 48);
	g->DrawEllipse(pen2, 221, 107, 45, 47);
	g->DrawEllipse(pen2, 273, 108, 43, 45);
	g->DrawEllipse(pen2, 26, 108, 24, 23);
	g->DrawEllipse(pen2, 322, 112, 25, 24);
	Brush^ brush2 = gcnew SolidBrush(Color::Black);
	g->FillEllipse(brush2, 34, 116, 8, 8);
	g->FillEllipse(brush2, 75, 123, 14, 14);
	g->FillEllipse(brush2, 129, 124, 14, 14);
	g->FillEllipse(brush2, 183, 124, 14, 14);
	g->FillEllipse(brush2, 237, 124, 14, 14);
	g->FillEllipse(brush2, 288, 124, 14, 14);
	g->FillEllipse(brush2, 331, 120, 8, 8);
	
	Point point42 = Point(191, 79), point43 = Point(238, 79), point44 = Point(236, 97), point45 = Point(189, 97);
	array <Point>^ Part8_1 = { point42, point43, point44, point45};
	g->DrawPolygon(pen, Part8_1);
	Point point46 = Point(136, 80), point47 = Point(172, 79), point48 = Point(172, 97), point49 = Point(135, 97);
	array <Point>^ Part8_2 = { point46, point47, point48, point49 };
	g->DrawPolygon(pen, Part8_2);

	Point point50 = Point(234, 64), point51 = Point(294, 64), point52 = Point(294, 87), point53 = Point(234, 87);
	array <Point>^ Part9_1 = { point50, point51, point52, point53 };
	g->FillPolygon(brush, Part9_1);
	Point point54 = Point(244, 64), point55 = Point(250, 64), point56 = Point(250, 92), point57 = Point(244, 92);
	array <Point>^ Part9_2 = { point54, point55, point56, point57 };
	g->DrawPolygon(pen, Part9_2);
	Point point58 = Point(280, 64), point59 = Point(286, 64), point60 = Point(286, 92), point61 = Point(280, 92);
	array <Point>^ Part9_3 = { point58, point59, point60, point61 };
	g->DrawPolygon(pen, Part9_3);
	g->DrawPolygon(pen, Part9_1);
}

private: System::Void Task3_Click(System::Object^  sender, System::EventArgs^  e) {
		Graphics^ g = pbMain->CreateGraphics();
		g->Clear(SystemColors::Control);
		int CenterX = 150, CenterY = 150;
		float r1 = 55, r2 = sqrt(100 * 100 + 50 * 50), r3 = 97;
		int x1, y1, x2, y2, x3, y3;
		float a = 0;
		Point Center = Point(CenterX, CenterY), PointEdge1, PointEdge2, PointEdge3;
		const float pi = acos(-1);
		Pen^ pen = gcnew Pen(Color::Black, 4);
		while (true)
		{
			g->Clear(SystemColors::Control);
			x1 = CenterX + r1 * cos(a - pi / 2);
			y1 = CenterY + r1 * sin(a - pi / 2);
			x2 = CenterX + r2 * cos(a - pi / 6);
			y2 = CenterY + r2 * sin(a - pi / 6);
			x3 = CenterX + r3 * cos(a);
			y3 = CenterY + r3 * sin(a);
			PointEdge1 = Point(x1, y1);
			PointEdge2 = Point(x2, y2);
			PointEdge3 = Point(x3, y3);
			array <Point>^ Rectangle = { Center, PointEdge1, PointEdge2, PointEdge3 };

			g->DrawPolygon(pen, Rectangle);
			//delete Rectangle;
			a += 0.04;
			if (a > pi * 2)
				break;
			Sleep(100);
		}
}

private: System::Void Task4_Click(System::Object^  sender, System::EventArgs^  e) 
{
	Graphics^ g = pbMain->CreateGraphics();

	Image^ f1 = Image::FromFile("Frames/1.bmp");
	Image^ f2 = Image::FromFile("Frames/2.bmp");
	Image^ f3 = Image::FromFile("Frames/3.bmp");
	Image^ f4 = Image::FromFile("Frames/4.bmp");
	Image^ f5 = Image::FromFile("Frames/5.bmp");
	Image^ f6 = Image::FromFile("Frames/6.bmp");
	Image^ f7 = Image::FromFile("Frames/7.bmp");
	Image^ f8 = Image::FromFile("Frames/8.bmp");
	Image^ f9 = Image::FromFile("Frames/9.bmp");
	Image^ f10 = Image::FromFile("Frames/10.bmp");

	g->DrawImage(f1, 0, 0, 309, 193);
	g->Clear(Color::White);
	int CounterFrame = 1;
	int CounterX = 0;
	while (true)
	{
		switch (CounterFrame)
		{
		case 1:
		{
			g->DrawImage(f1, CounterX, 0, 309, 193);
			break;
		}
		case 2:
		{
			g->DrawImage(f2, CounterX + 1, 0, 309, 193);
			break;
		}
		case 3:
		{
			g->DrawImage(f3, CounterX + 1, 0, 309, 193);
			break;
		}
		case 4:
		{
			g->DrawImage(f4, CounterX + 2, 0, 309, 193);
			break;
		}
		case 5:
		{
			g->DrawImage(f5, CounterX + 2, 0, 309, 193);
			break;
		}
		case 6:
		{
			g->DrawImage(f6, CounterX + 3, 0, 309, 193);
			break;
		}
		case 7:
		{
			g->DrawImage(f7, CounterX + 3, 0, 309, 193);
			break;
		}
		case 8:
		{
			g->DrawImage(f8, CounterX + 4, 0, 309, 193);
			break;
		}
		case 9:
		{
			g->DrawImage(f9, CounterX + 4, 0, 309, 193);
			break;
		}
		case 10:
		{
			g->DrawImage(f10, CounterX + 5, 0, 309, 193);
			break;
		}
		}
		CounterFrame ++;
		if (CounterFrame > 10)
			CounterFrame = 0;
		CounterX+=5;
		if (CounterX > 170)
			break;
	Sleep(150);
	}
}
};
}
